
 export const BarChartData = [
    {
      id: 1,
      year: "Total Occupied",
      userGain: 1000,
      userLost: 823,
      color: "tomato",
    },
    {
      id: 2,
      year: "Total Occupied",
      userGain: 2000,
      userLost: 345,
      color: "#FFA500",
    },
    {
      id: 3,
      year: "vacant",
      userGain: 3000,
      userLost: 555,
      color: "#6B8E23",
    },
    {
      id: 4,
      year: "Maintenance",
      userGain: 2000,
      userLost: 4555,
      color: "#0d6efd",
    },
  ];