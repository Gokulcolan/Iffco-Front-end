import React from 'react'
import RoomInfoTableData from './RoomInfoTableData';

const RoomInfo = () => {



  return (
    <div>
      <RoomInfoTableData />

    </div>
  )
}

export default RoomInfo