export const AUTH_BASE_URL = process.env.AUTH_BASE_URL
  ? process.env.AUTH_BASE_URL
  : "";
