const Tickets = () => {
  return <>Tickets Screen</>;
};

export default Tickets;
