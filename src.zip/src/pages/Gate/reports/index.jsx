import ReportsData from "./ReportsData";

const Report = () => {
  return (
    <>
      <div>
        {" "}
        <ReportsData />
      </div>
    </>
  );
};

export default Report;
