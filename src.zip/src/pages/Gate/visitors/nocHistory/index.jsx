const NOC = ()=>{
    return(
        <>
            NOC Screen
        </>
    )
}

export default NOC;