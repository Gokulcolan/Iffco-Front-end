const ApplyGatePass = ()=>{
    return(
        <>
            ApplyGatePass Screen
        </>
    )
}

export default ApplyGatePass;