const Vistior = ()=>{
    return(
        <>
            Vistior Screen
        </>
    )
}

export default Vistior;