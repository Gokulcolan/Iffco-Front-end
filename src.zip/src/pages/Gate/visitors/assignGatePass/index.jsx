const AssignGatePass = ()=>{
    return(
        <>
            AssignGatePass Screen
        </>
    )
}

export default AssignGatePass;