export const Dashboard = () => {
  return (
    <>
      <h1>HELLO Dashboard</h1>
    </>
  );
};
